import Link from 'next/link'
import products from '../data/products.json'

export default function Home() {
  return (
    <div style={{padding:40,fontFamily:'Arial'}}>
      <h1>My Online Store</h1>
      <p>Welcome to my ecommerce website</p>

      <div style={{display:'grid',gridTemplateColumns:'repeat(auto-fit,minmax(200px,1fr))',gap:20,marginTop:30}}>
        {products.map(p => (
          <div key={p.id} style={{border:'1px solid #ddd',padding:20}}>
            <img src={p.image} style={{width:'100%'}}/>
            <h3>{p.name}</h3>
            <p>{p.price} ৳</p>
            <Link href={`/product/${p.id}`}>View</Link>
          </div>
        ))}
      </div>
    </div>
  )
}
