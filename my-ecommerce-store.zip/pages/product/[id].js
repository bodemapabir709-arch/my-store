import { useRouter } from 'next/router'
import products from '../../data/products.json'

export default function ProductPage(){
  const router = useRouter()
  const { id } = router.query

  const product = products.find(p => p.id == id)
  if(!product) return <p style={{padding:40}}>Loading...</p>

  function addToCart(){
    const cart = JSON.parse(localStorage.getItem('cart') || '[]')
    cart.push(product)
    localStorage.setItem('cart', JSON.stringify(cart))
    alert("Added to cart")
  }

  return (
    <div style={{padding:40,fontFamily:'Arial'}}>
      <h1>{product.name}</h1>
      <img src={product.image} style={{width:300}}/>
      <p>{product.description}</p>
      <h3>{product.price} ৳</h3>
      <button onClick={addToCart}>Add to Cart</button>
    </div>
  )
}
