import { useEffect, useState } from 'react'

export default function Cart(){
  const [cart,setCart] = useState([])

  useEffect(()=>{
    const c = JSON.parse(localStorage.getItem('cart') || '[]')
    setCart(c)
  },[])

  return (
    <div style={{padding:40,fontFamily:'Arial'}}>
      <h1>Your Cart</h1>
      {cart.map((p,i)=>(
        <div key={i}>
          {p.name} - {p.price} ৳
        </div>
      ))}
    </div>
  )
}
